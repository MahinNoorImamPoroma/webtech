<ul>
        <li><a href="addProduct.php"> Add Product</a></li>
        <li><a href="showAllProducts.php"> Show all prodcuts</a></li>
        <li><a href="searchUser.php"> Search Products</a></li>
        
    </ul>